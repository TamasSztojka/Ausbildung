﻿using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        string filePath = "test.txt";

        try
        {
            Task<string> readTask = ReadFileAsync(filePath);

            while (!readTask.IsCompleted)
            {
                Console.WriteLine("Datei wird geladen...");
                await Task.Delay(500);
            }

            string content = await readTask;
            Console.WriteLine("\n--- Dateiinhalte ---");
            Console.WriteLine(content);
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("❌ Die Datei wurde nicht gefunden.");
        }
        catch (UnauthorizedAccessException)
        {
            Console.WriteLine("❌ Kein Zugriff auf die Datei.");
        }
        catch (Exception exception)
        {
            Console.WriteLine($"❌ Unerwarteter Fehler: {exception.Message}");
        }
    }

    static async Task<string> ReadFileAsync(string path)
    {
        StringBuilder stringBuilder = new StringBuilder();

        using StreamReader reader = new StreamReader(path);

        while (!reader.EndOfStream)
        {
            string? line = await reader.ReadLineAsync();
            stringBuilder.AppendLine(line);

            await Task.Delay(1);
        }

        return stringBuilder.ToString();
    }
}