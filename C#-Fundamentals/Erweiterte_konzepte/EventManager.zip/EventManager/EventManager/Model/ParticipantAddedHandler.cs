﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventManagement.Model
{
    public delegate void ParticipantAddedHandler(object sender, Participant participant);
}
