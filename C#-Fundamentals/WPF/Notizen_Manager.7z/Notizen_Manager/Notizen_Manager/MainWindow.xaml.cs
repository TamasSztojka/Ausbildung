﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Notizen_Manager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            string text = NoteTextBox.Text.Trim();

            // Validation: no empty notes
            if (string.IsNullOrWhiteSpace(text))
            {
                MessageBox.Show("Note cannot be empty.", "Validation",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            NotesListBox.Items.Add(text);
            NoteTextBox.Clear();
            NoteTextBox.Focus();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (NotesListBox.SelectedItem != null)
            {
                NotesListBox.Items.Remove(NotesListBox.SelectedItem);
            }
            else
            {
                MessageBox.Show("Please select a note to delete.", "Info",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}