﻿namespace Rechnungs_Manager.Models
{
    public class Customer
    {
        public string Name { get; set; } = "";
        public string Number { get; set; } = "KU-";
    }
}
